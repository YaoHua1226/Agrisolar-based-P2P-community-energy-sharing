"""
This codes reconstructs WDCH farm-type workbook values for 1990-2027. It reads
QLD benchmark tables and WDCH raw totals, applies proportional allocation rules,
then writes the computed values back to the WDCH output sheets. The 2025-2027
extension uses recursive four-year moving averages. The script can optionally
compare the generated workbook with a cleaned reference workbook.

Production and receipts
crop_output = crop_area * QLD_output / QLD_area
receipt = output_or_area * QLD_receipt / QLD_output_or_area

Financial closure
farm_cash_income = total_cash_receipts - total_cash_costs
farm_business_profit = farm_cash_income - allocated_profit_gap
profit_at_full_equity = farm_business_profit + allocated_full_equity_gap
"""

from __future__ import annotations

import argparse, math, statistics
from pathlib import Path
from typing import Dict, List, Mapping, Optional

import openpyxl

# These are the six crop-area variables that are normalized together so that
# their sum does not exceed total area cropped.
COMPONENT_VARS = [
    ("Barley area sown (ha)", "QLD_A1"),
    ("Grain legumes area sown (ha)", "QLD_A1"),
    ("Sorghum area sown (ha)", "QLD_A1"),
    ("Wheat area sown (ha)", "QLD_A1"),
    ("Oats area sown (ha)", "QLD_B"),
    ("Oilseeds area sown (ha)", "QLD_B"),
]
PROD_AREA_PAIRS = {"Barley produced (t)": "Barley area sown (ha)", "Grain legumes produced (t)": "Grain legumes area sown (ha)", "Sorghum produced (t)": "Sorghum area sown (ha)", "Wheat produced (t)": "Wheat area sown (ha)"}
SHEEP_DETAIL_VARS = ["Ewes at 30 June (no.)", "Rams at 30 June (no.)", "Sheep and lambs shorn (no.)", "Wethers at 30 June (no.)"]
CROP_RECEIPT_SPECS = [("Barley receipts ($)", "Barley produced (t)", "Barley area sown (ha)"), ("Grain legumes receipts ($)", "Grain legumes produced (t)", "Grain legumes area sown (ha)"), ("Sorghum receipts ($)", "Sorghum produced (t)", "Sorghum area sown (ha)"), ("Wheat receipts ($)", "Wheat produced (t)", "Wheat area sown (ha)")]


SHEET_TO_TYPE = {"WDCH Cropping": "Cropping", "WDCH Mixed": "Mixed", "WDCH Grazing": "Grazing"}


def nz(value: Optional[float]) -> float:
    return 0.0 if value is None or (isinstance(value, float) and math.isnan(value)) else float(value)

# Safe division; returns zero when denominator is zero, otherwise numerator/denominator.
def safe_div(numerator: Optional[float], denominator: Optional[float]) -> float:
    d = nz(denominator)
    return 0.0 if d == 0 else nz(numerator) / d


def load_qld_lookup(wb: openpyxl.Workbook, sheet_name: str) -> Dict[str, Dict[int, Dict[str, float]]]:
    ws = wb[sheet_name]
    headers = [ws.cell(1, c).value for c in range(1, ws.max_column + 1)]
    return _qld_rows(ws, headers)

# Convert rows in a QLD sheet into a nested lookup dictionary.
def _qld_rows(ws, headers):
    lookup: Dict[str, Dict[int, Dict[str, float]]] = {}
    for r in range(2, ws.max_row + 1):
        row = {headers[c - 1]: ws.cell(r, c).value for c in range(1, ws.max_column + 1)}
        lookup.setdefault(row["Industry"], {})[int(row["Year"])] = row
    return lookup

# Read WDCH RAW Data into a variable/year lookup table.
def load_wdch_raw_lookup(wb: openpyxl.Workbook) -> Dict[str, Dict[int, float]]:
    ws = wb["WDCH RAW Data"]
    year_cols = [(c, int(ws.cell(7, c).value)) for c in range(2, ws.max_column + 1) if ws.cell(7, c).value is not None]
    return {ws.cell(r, 1).value: {y: ws.cell(r, c).value for c, y in year_cols} for r in range(8, ws.max_row + 1) if ws.cell(r, 1).value}


def get_years_from_output_sheet(ws: openpyxl.worksheet.worksheet.Worksheet) -> List[int]:
    return [int(ws.cell(7, c).value) for c in range(2, ws.max_column + 1) if ws.cell(7, c).value is not None]


def get_variable_rows(ws: openpyxl.worksheet.worksheet.Worksheet) -> Dict[str, int]:
    return {str(ws.cell(r, 1).value): r for r in range(8, ws.max_row + 1) if ws.cell(r, 1).value}

# Container class for QLD tables and WDCH RAW Data lookups.
class SourceLookup:
    def __init__(self, wb: openpyxl.Workbook):
        self.qld = {s: load_qld_lookup(wb, s) for s in ["QLD_A1", "QLD_A2", "QLD_B"]}
        self.raw = load_wdch_raw_lookup(wb)

    def q(self, sheet: str, industry: str, year: int, var: str) -> float:
        """Get a QLD value, returning 0 if anything is missing.
        """
        return nz(self.qld[sheet].get(industry, {}).get(year, {}).get(var, 0))

    def rraw(self, var: str, year: int) -> float:
        """Get WDCH RAW Data value, returning 0 if missing.
        """
        return nz(self.raw.get(var, {}).get(year, 0))

# Compute 1990-2027 WDCH values for one farm type, including short-term extension.
def compute_type_history(ftype: str, source: SourceLookup) -> Dict[str, Dict[int, float]]:
    out: Dict[str, Dict[int, float]] = {}

    # Helper to write a value into the result dictionary.
    def set_value(var: str, year: int, value: float) -> None:
        out.setdefault(var, {})[year] = value
    q, rraw, sv = source.q, source.rraw, set_value

    # Historical reconstruction uses same-year QLD information for 1990–2024.
    for year in range(1990, 2025):
        area_operated = rraw("Area operated at 30 June (ha)", year) * safe_div(q("QLD_A1", ftype, year, "Area operated at 30 June (ha)"), q("QLD_A1", "All Broadacre", year, "Area operated at 30 June (ha)"))
        sv("Area operated at 30 June (ha)", year, area_operated)
        total_area_cropped = max(0.0, min(area_operated, area_operated * safe_div(q("QLD_A1", ftype, year, "Total area cropped (ha)"), q("QLD_A1", ftype, year, "Area operated at 30 June (ha)"))))
        sv("Total area cropped (ha)", year, total_area_cropped)
        total_area_irrigated = max(0.0, min(total_area_cropped, total_area_cropped * safe_div(q("QLD_A1", ftype, year, "Total area irrigated (ha)"), q("QLD_A1", ftype, year, "Total area cropped (ha)"))))
        sv("Total area irrigated (ha)", year, total_area_irrigated)
        denom_crop = max(q("QLD_A1", ftype, year, "Total area cropped (ha)"), sum(q(sheet, ftype, year, var) for var, sheet in COMPONENT_VARS))
        for var, sheet in COMPONENT_VARS:
            sv(var, year, total_area_cropped * safe_div(q(sheet, ftype, year, var), denom_crop))
        beef_herd = area_operated * safe_div(q("QLD_A2", ftype, year, "Beef herd at 30 June (no.)"), q("QLD_A1", ftype, year, "Area operated at 30 June (ha)"))
        sheep_flock = area_operated * safe_div(q("QLD_A2", ftype, year, "Sheep flock at 30 June (no.)"), q("QLD_A1", ftype, year, "Area operated at 30 June (ha)"))
        sv("Beef herd at 30 June (no.)", year, beef_herd); sv("Sheep flock at 30 June (no.)", year, sheep_flock)
        for name, base, denom in [("Beef cattle receipts ($)", beef_herd, "Beef herd at 30 June (no.)"), ("Sheep receipts ($)", sheep_flock, "Sheep flock at 30 June (no.)")]:
            sv(name, year, base * safe_div(q("QLD_A2", ftype, year, name), q("QLD_A2", ftype, year, denom)))
        for name in ["Electricity ($)", "Total cash costs ($)"]:
            sv(name, year, area_operated * safe_div(q("QLD_A2", ftype, year, name), q("QLD_A1", ftype, year, "Area operated at 30 June (ha)")))
        for prod_var, area_var in PROD_AREA_PAIRS.items():
            sv(prod_var, year, out[area_var][year] * safe_div(q("QLD_B", ftype, year, prod_var), q("QLD_A1", ftype, year, area_var)))
        for var in SHEEP_DETAIL_VARS:
            sv(var, year, sheep_flock * safe_div(q("QLD_B", ftype, year, var), q("QLD_A2", ftype, year, "Sheep flock at 30 June (no.)")))
        shorn = out["Sheep and lambs shorn (no.)"][year]
        for var in ["Total wool sold (kg)", "Wool produced (kg)"]:
            sv(var, year, shorn * safe_div(q("QLD_B", ftype, year, var), q("QLD_B", ftype, year, "Sheep and lambs shorn (no.)")))
        if q("QLD_A1", ftype, year, "Total area irrigated (ha)") > 0:
            water_charges = total_area_irrigated * safe_div(q("QLD_B", ftype, year, "Water charges ($)"), q("QLD_A1", ftype, year, "Total area irrigated (ha)"))
        else:
            water_charges = area_operated * safe_div(q("QLD_B", ftype, year, "Water charges ($)"), q("QLD_A1", ftype, year, "Area operated at 30 June (ha)"))
        sv("Water charges ($)", year, water_charges)
        for receipt_var, output_var, area_var in CROP_RECEIPT_SPECS:
            value = out[output_var][year] * safe_div(q("QLD_A2", ftype, year, receipt_var), q("QLD_B", ftype, year, output_var)) if q("QLD_B", ftype, year, output_var) > 0 else out[area_var][year] * safe_div(q("QLD_A2", ftype, year, receipt_var), q("QLD_A1", ftype, year, area_var))
            sv(receipt_var, year, value)
        if q("QLD_A1", ftype, year, "Total area cropped (ha)") > 0:
            cotton_receipts = total_area_cropped * safe_div(q("QLD_B", ftype, year, "Cotton receipts ($)"), q("QLD_A1", ftype, year, "Total area cropped (ha)"))
        else:
            cotton_receipts = area_operated * safe_div(q("QLD_B", ftype, year, "Cotton receipts ($)"), q("QLD_A1", ftype, year, "Area operated at 30 June (ha)"))
        sv("Cotton receipts ($)", year, cotton_receipts)
        for area_var, receipt_var in [("Oats area sown (ha)", "Oats receipts ($)"), ("Oilseeds area sown (ha)", "Oilseeds receipts ($)")]:
            value = out[area_var][year] * safe_div(q("QLD_B", ftype, year, receipt_var), q("QLD_B", ftype, year, area_var)) if q("QLD_B", ftype, year, area_var) > 0 else total_area_cropped * safe_div(q("QLD_B", ftype, year, receipt_var), q("QLD_A1", ftype, year, "Total area cropped (ha)"))
            sv(receipt_var, year, value)
        wool_base, wool_denom = ("Total wool sold (kg)", "Total wool sold (kg)") if q("QLD_B", ftype, year, "Total wool sold (kg)") > 0 else ("Wool produced (kg)", "Wool produced (kg)")
        wool_receipts = out[wool_base][year] * safe_div(q("QLD_A2", ftype, year, "Wool receipts ($)"), q("QLD_B", ftype, year, wool_denom))
        sv("Wool receipts ($)", year, wool_receipts)
        residual_crop = q("QLD_A2", ftype, year, "Total crop gross receipts ($)") - q("QLD_A2", ftype, year, "Barley receipts ($)") - q("QLD_A2", ftype, year, "Grain legumes receipts ($)") - q("QLD_A2", ftype, year, "Sorghum receipts ($)") - q("QLD_A2", ftype, year, "Wheat receipts ($)") - q("QLD_B", ftype, year, "Oats receipts ($)") - q("QLD_B", ftype, year, "Oilseeds receipts ($)") - q("QLD_B", ftype, year, "Cotton receipts ($)")
        total_crop_gross_receipts = out["Barley receipts ($)"][year] + out["Grain legumes receipts ($)"][year] + out["Sorghum receipts ($)"][year] + out["Wheat receipts ($)"][year] + out["Cotton receipts ($)"][year] + out["Oats receipts ($)"][year] + out["Oilseeds receipts ($)"][year] + total_area_cropped * safe_div(residual_crop, q("QLD_A1", ftype, year, "Total area cropped (ha)"))
        sv("Total crop gross receipts ($)", year, total_crop_gross_receipts)
        residual_cash = q("QLD_A2", ftype, year, "Total cash receipts ($)") - q("QLD_A2", ftype, year, "Total crop gross receipts ($)") - q("QLD_A2", ftype, year, "Beef cattle receipts ($)") - q("QLD_A2", ftype, year, "Sheep receipts ($)") - q("QLD_A2", ftype, year, "Wool receipts ($)")
        total_cash_receipts = total_crop_gross_receipts + out["Beef cattle receipts ($)"][year] + out["Sheep receipts ($)"][year] + out["Wool receipts ($)"][year] + area_operated * safe_div(residual_cash, q("QLD_A1", ftype, year, "Area operated at 30 June (ha)"))
        sv("Total cash receipts ($)", year, total_cash_receipts)
        farm_cash_income = total_cash_receipts - out["Total cash costs ($)"][year]
        sv("Farm cash income ($)", year, farm_cash_income)
        profit_gap = q("QLD_B", ftype, year, "Farm cash income ($)") - q("QLD_B", ftype, year, "Farm business profit ($)")
        farm_business_profit = farm_cash_income - area_operated * safe_div(profit_gap, q("QLD_A1", ftype, year, "Area operated at 30 June (ha)"))
        sv("Farm business profit ($)", year, farm_business_profit)
        pfe_gap = q("QLD_B", ftype, year, "Profit at full equity ($)") - q("QLD_B", ftype, year, "Farm business profit ($)")
        sv("Profit at full equity ($)", year, farm_business_profit + area_operated * safe_div(pfe_gap, q("QLD_A1", ftype, year, "Area operated at 30 June (ha)")))

    # Forecast extension for 2025–2027 uses recursive 4-year moving averages.
    for var in list(out.keys()):
        out[var][2025] = statistics.mean([nz(out[var][y]) for y in [2024, 2023, 2022, 2021]])
        out[var][2026] = statistics.mean([nz(out[var][y]) for y in [2025, 2024, 2023, 2022]])
        out[var][2027] = statistics.mean([nz(out[var][y]) for y in [2026, 2025, 2024, 2023]])
    return out

# Write forecast results back to the workbook only for target forecast years.
def write_results_to_workbook(wb: openpyxl.Workbook, results: Mapping[str, Mapping[str, Mapping[int, float]]]) -> None:
    for sheet_name, ftype in SHEET_TO_TYPE.items():
        ws, years = wb[sheet_name], get_years_from_output_sheet(wb[sheet_name])
        year_cols, variable_rows = list(range(2, 2 + len(years))), get_variable_rows(ws)

        # Update the small title label in row 6 
        ws["A6"] = ftype

        # Clear any stray cells to the right of the year block.
        for row_idx in range(8, ws.max_row + 1):
            for c in range(2 + len(years), ws.max_column + 1):
                ws.cell(row_idx, c).value = None
        for var, row_idx in variable_rows.items():
            series = results[ftype].get(var, {})
            for c, year in zip(year_cols, years):
                ws.cell(row_idx, c).value = series.get(year)


# Compare generated and reference workbooks cell by cell
# and return max absolute difference.
def compare_with_reference(output_path: Path, reference_path: Path) -> Dict[str, float]:
    out_wb, ref_wb = openpyxl.load_workbook(output_path, data_only=True), openpyxl.load_workbook(reference_path, data_only=True)
    max_abs_diff = compared_cells = 0
    for sheet_name in SHEET_TO_TYPE:
        out_ws, ref_ws = out_wb[sheet_name], ref_wb[sheet_name]
        year_cols = [c for c in range(2, out_ws.max_column + 1) if out_ws.cell(7, c).value is not None]
        for r in range(8, out_ws.max_row + 1):
            if not out_ws.cell(r, 1).value:
                continue
            for c in year_cols:
                out_val, ref_val = out_ws.cell(r, c).value, ref_ws.cell(r, c).value
                if out_val is None and ref_val is None:
                    continue
                max_abs_diff = max(max_abs_diff, abs(nz(out_val) - nz(ref_val))); compared_cells += 1
    return {"compared_cells": compared_cells, "max_abs_diff": max_abs_diff}



def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="Python_Version_with_Data_Dictionary.xlsx")
    parser.add_argument("--output", default="Python_Version_Final.xlsx")
    parser.add_argument("--reference", default="Cleaned Data.xlsx")
    return parser.parse_args([])



def main() -> None:
    args = parse_args()
    input_path, output_path = Path(args.input), Path(args.output)
    wb = openpyxl.load_workbook(input_path)
    source = SourceLookup(wb)
    results = {ftype: compute_type_history(ftype, source) for ftype in SHEET_TO_TYPE.values()}
    write_results_to_workbook(wb, results); wb.save(output_path)
    print(f"Saved output workbook: {output_path}")
    if args.reference:
        stats = compare_with_reference(output_path, Path(args.reference))
        print("Validation:", f"compared_cells={stats['compared_cells']}", f"max_abs_diff={stats['max_abs_diff']}")


if __name__ == "__main__":
    main()
