

"""
ARIMA-only forecast for WDCH farm-type data, 2028-2044, preserving 1990-2027 exactly.

   ARIMA is the only statistical model family used. Other steps are algebraic
   transformations or project-specific controls.

   The official 2025-2027 values are used only as a light reference (~10%)
   for early forecast growth, not as full model-fitting data.

   The forecast path should be piecewise / broken-line rather than mechanically
   monotonic. Therefore, the fitted ARIMA model is used twice:
   (a) to generate a baseline point forecast; and
   (b) to simulate future paths, from which one representative non-monotonic path
       is chosen subject to historical growth bounds and a modest upper cap.
Main formulas
   ARIMA(p,d,q):
   φ(B)(1-B)^d y_t = δ t + θ(B) ε_t

   Positive-series transform:
   z_t = log(1 + y_t),     y_t = exp(z_t) - 1

   Holdout model selection metric:
   MASE = mean(|e_j|) / ((1/(T-1)) * Σ_{t=2..T}|y_t - y_{t-1}|)

   Official 2025-2027 light-reference blending (project-specific rule):
    For positive series:
        g_t^OFF = (z_2027^OFF - z_2024) / 3
        z_t^BASE = z_{t-1}^BASE + (1-α_t) g_t^ARIMA + α_t g_t^OFF
    For signed series:
        d_t^OFF = (y_2027^OFF - y_2024) / 3
        y_t^BASE = y_{t-1}^BASE + (1-α_t) d_t^ARIMA + α_t d_t^OFF
    where α_t <= 0.10 and decays after 2028.

    Representative path from ARIMA simulations (project-specific rule):
    path_t = base_t + β_t (sim_t - point_t)
    where β_t is a small damping weight, then the path is filtered by
    historical-growth bounds and a modest upper cap.

    Dynamic cap and growth corridor from 1990-2024 actual data (project-specific rule):
    x_t^* = min(U, max(L, x_t))
    g_t^* = min(g_high, max(g_low, g_t))

    Structural and accounting closure:
    Crop sub-areas, crop outputs, wool variables, sheep subgroups, and crop
    component receipts are generated algebraically from recent historical ratios,
    while total cash receipts / costs / profits are closed exactly from the
    forecasted top-level drivers and helper series.

References
R. J. Hyndman and Y. Khandakar, "Automatic Time Series Forecasting:
The forecast Package for R," Journal of Statistical Software, vol. 27,
no. 3, pp. 1-22, 2008, doi: 10.18637/jss.v027.i03.

G. E. P. Box and D. R. Cox, "An Analysis of Transformations,"
Journal of the Royal Statistical Society: Series B (Methodological),
vol. 26, no. 2, pp. 211-243, 1964, doi: 10.1111/j.2517-6161.1964.tb00553.x.

R. J. Hyndman and A. B. Koehler, "Another look at measures of forecast
accuracy," International Journal of Forecasting, vol. 22, no. 4,
pp. 679-688, 2006, doi: 10.1016/j.ijforecast.2006.03.001.

S. L. Wickramasuriya, G. Athanasopoulos, and R. J. Hyndman,
"Optimal Forecast Reconciliation for Hierarchical and Grouped Time Series
Through Trace Minimization," Journal of the American Statistical Association,
vol. 114, no. 526, pp. 804-819, 2019, doi: 10.1080/01621459.2018.1448825.
"""

from __future__ import annotations

import argparse, math, warnings
from copy import copy
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Tuple

import numpy as np
import openpyxl
from statsmodels.tools.sm_exceptions import ConvergenceWarning
from statsmodels.tsa.arima.model import ARIMA

warnings.filterwarnings("ignore", category=ConvergenceWarning)
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)

FARM_TYPES = ["Cropping", "Mixed", "Grazing"]
WDCH_SHEETS = {ftype: f"WDCH {ftype}" for ftype in FARM_TYPES}

DIRECT_VARS = [
    "Area operated at 30 June (ha)",
    "Total area cropped (ha)",
    "Total area irrigated (ha)",
    "Beef herd at 30 June (no.)",
    "Sheep flock at 30 June (no.)",
    "Total crop gross receipts ($)",
    "Beef cattle receipts ($)",
    "Sheep receipts ($)",
    "Wool receipts ($)",
    "Electricity ($)",
    "Water charges ($)",
]

HELPER_VARS = [
    "Other cash receipts ($)",
    "Other cash costs ($)",
    "Profit gap ($)",
    "Full-equity gap ($)",
]

POSITIVE_VARS = set(
    DIRECT_VARS
    + ["Other cash receipts ($)", "Other cash costs ($)", "Full-equity gap ($)"]
)

SIGNED_VARS = {"Profit gap ($)"}

CROP_AREA_VARS = [
    "Barley area sown (ha)",
    "Grain legumes area sown (ha)",
    "Sorghum area sown (ha)",
    "Wheat area sown (ha)",
    "Oats area sown (ha)",
    "Oilseeds area sown (ha)",
]

CROP_OUTPUT_AREA_MAP = {
    "Barley produced (t)": "Barley area sown (ha)",
    "Grain legumes produced (t)": "Grain legumes area sown (ha)",
    "Sorghum produced (t)": "Sorghum area sown (ha)",
    "Wheat produced (t)": "Wheat area sown (ha)",
}

CROP_RECEIPT_OUTPUT_MAP = {
    "Barley receipts ($)": "Barley produced (t)",
    "Grain legumes receipts ($)": "Grain legumes produced (t)",
    "Sorghum receipts ($)": "Sorghum produced (t)",
    "Wheat receipts ($)": "Wheat produced (t)",
}

CROP_RECEIPT_AREA_MAP = {
    "Oats receipts ($)": "Oats area sown (ha)",
    "Oilseeds receipts ($)": "Oilseeds area sown (ha)",
}

SHEEP_SUBGROUP_CAPS = {
    "Ewes at 30 June (no.)": 1.0,
    "Rams at 30 June (no.)": 1.0,
    "Wethers at 30 June (no.)": 1.0,
    "Sheep and lambs shorn (no.)": 1.5,
}



def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Forecast only 2028-2044 for WDCH sheets while preserving 1990-2027 exactly.")
    for flags, kwargs in [(("--input",), dict(default="Python_Version_Final.xlsx", help="Input workbook")), (("--output",), dict(default="Forecast_2044.xlsx", help="Output workbook")), (("--start-year",), dict(type=int, default=2028, help="Forecast start")), (("--end-year",), dict(type=int, default=2044, help="Forecast end"))]:
        parser.add_argument(*flags, **kwargs)
    args, _ = parser.parse_known_args(argv)
    return args


# Convert blank/NaN values to zero so downstream formulas remain numeric.
def nz(value: Optional[float]) -> float:
    return 0.0 if value is None or (isinstance(value, float) and math.isnan(value)) else float(value)


# Read all year labels from the workbook year row.
def get_years(ws: openpyxl.worksheet.worksheet.Worksheet) -> List[int]:
    return [int(ws.cell(7, c).value) for c in range(2, ws.max_column + 1) if ws.cell(7, c).value is not None]


# Build a mapping from variable labels to Excel row/volume numbers.
def get_row_map(ws: openpyxl.worksheet.worksheet.Worksheet) -> Dict[str, int]:
    return {str(ws.cell(r, 1).value): r for r in range(8, ws.max_row + 1) if ws.cell(r, 1).value}

def get_col_map(ws: openpyxl.worksheet.worksheet.Worksheet) -> Dict[int, int]:
    return {int(ws.cell(7, c).value): c for c in range(2, ws.max_column + 1) if ws.cell(7, c).value is not None}


# Read one variable row into a year-to-value series.
def read_visible_series(ws: openpyxl.worksheet.worksheet.Worksheet, var: str) -> Dict[int, float]:
    r, col_map = get_row_map(ws)[var], get_col_map(ws)
    return {year: nz(ws.cell(r, c).value) for year, c in col_map.items()}


# Compute a recent mean ratio: ratio = mean(numerator/denominator), skipping zero denominators.
def recent_mean_ratio(numer: Mapping[int, float], denom: Mapping[int, float], years: Iterable[int], default: float = 0.0) -> float:
    ratios = [nz(numer.get(y)) / nz(denom.get(y)) for y in years if abs(nz(denom.get(y))) > 1e-12]
    return float(np.mean(ratios)) if ratios else default


# Transform model-scale values back to the original scale; log1p models use y = exp(z) - 1.
def inverse_transform(values: np.ndarray, use_log: bool) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    return np.expm1(arr) if use_log else arr


# Compute MASE: MASE = mean(|error|) / mean(|Δtrain|), used for holdout model selection.
def mase(actual: np.ndarray, forecast: np.ndarray, train: np.ndarray) -> float:
    actual, forecast, train = map(lambda x: np.asarray(x, dtype=float), (actual, forecast, train))
    denom = np.mean(np.abs(np.diff(train)))
    if (not np.isfinite(denom)) or denom <= 1e-12:
        denom = np.mean(np.abs(train))
    if (not np.isfinite(denom)) or denom <= 1e-12:
        denom = 1.0
    return float(np.mean(np.abs(actual - forecast)) / denom)


# Return the project-approved ARIMA(p,d,q) candidate set.
def arima_candidates(var: str) -> List[Tuple[Tuple[int, int, int], str]]:
    return [((0, 0, 0), "c"), ((1, 0, 0), "c"), ((0, 0, 1), "c"), ((1, 0, 1), "c")] if var in SIGNED_VARS else [((p, 1, q), t) for p, q in [(0, 0), (1, 0), (0, 1), (1, 1)] for t in ["n", "t"]]

# Fit and select an ARIMA model using historical data and holdout MASE.
def fit_select_arima(history_actual: List[float], var: str) -> Dict[str, object]:
    hist = np.asarray(history_actual, dtype=float)
    use_log = bool(var in POSITIVE_VARS and np.all(hist >= 0))
    transformed = np.log1p(hist) if use_log else hist

    h = 7 if len(hist) >= 20 else max(3, len(hist) // 5)
    train_t = transformed[:-h]
    test_o = hist[-h:]
    train_o = hist[:-h]

    scored: List[Tuple[float, Tuple[int, int, int], str]] = []
    for order, trend in arima_candidates(var):
        try:
            res = ARIMA(
                train_t,
                order=order,
                trend=trend,
                enforce_stationarity=False,
                enforce_invertibility=False,
            ).fit()
            pred_t = np.asarray(res.forecast(steps=h), dtype=float)
            pred_o = inverse_transform(pred_t, use_log)
            if use_log:
                pred_o = np.maximum(pred_o, 0.0)
            scored.append((mase(test_o, pred_o, train_o), order, trend))
        except Exception:
            scored.append((1e18, order, trend))

    scored.sort(key=lambda x: x[0])
    best_score, best_order, best_trend = scored[0]

    full_res = ARIMA(
        transformed,
        order=best_order,
        trend=best_trend,
        enforce_stationarity=False,
        enforce_invertibility=False,
    ).fit()

    return {
        "result": full_res,
        "use_log": use_log,
        "order": best_order,
        "trend": best_trend,
        "holdout_mase": float(best_score),
    }


# Set the small official-reference weight for early forecast years, decaying over time.
def official_weight(year: int) -> float:
    return float({2028: 0.10, 2029: 0.08, 2030: 0.06, 2031: 0.04, 2032: 0.02}.get(year, 0.0))


# Normalize ARIMA simulation output to steps by repetitions.
def squeeze_simulation_array(sim: np.ndarray) -> np.ndarray:
    arr = np.asarray(sim, dtype=float)
    if arr.ndim == 3:
        arr = arr[:, 0, :] if arr.shape[1] == 1 else arr[:, :, 0] if arr.shape[2] == 1 else arr
    if arr.ndim == 1:
        arr = arr.reshape(-1, 1)
    return arr.T if arr.shape[0] == 1 and arr.shape[1] > 1 else arr


# Derive a historical upper cap to prevent unreasonable extrapolation.
def historical_upper_cap(var: str, history_actual: List[float]) -> float:
    """Slightly relaxed but still controlled upper cap from 1990-2024 actual data.
    """
    hist, pos_hist = np.asarray(history_actual, dtype=float), np.maximum(np.asarray(history_actual, dtype=float), 0.0)
    hmax = float(np.max(pos_hist)) if len(pos_hist) else 0.0
    recent = pos_hist[-7:] if len(pos_hist) >= 7 else pos_hist
    recent_max = float(np.max(recent)) if len(recent) else hmax
    recent_sd = float(np.std(recent, ddof=1)) if len(recent) >= 2 else 0.0
    if var == "Area operated at 30 June (ha)":
        return max(hmax * 1.08, recent_max + 0.50 * recent_sd)
    if var == "Total area cropped (ha)":
        return max(hmax * 1.12, recent_max + 0.60 * recent_sd)
    if var == "Total area irrigated (ha)":
        return max(hmax * 1.25, recent_max + 0.80 * recent_sd)
    if var in {"Beef herd at 30 June (no.)", "Sheep flock at 30 June (no.)"}:
        return max(hmax * 1.12, recent_max + 0.50 * recent_sd)
    if var in POSITIVE_VARS:
        return max(hmax * 1.18, recent_max + 0.75 * recent_sd)
    absmax = max(abs(float(np.min(hist))), abs(float(np.max(hist)))) if len(hist) else 0.0
    return absmax * 1.18

# Build annual growth corridors from historical growth distributions.
def historical_growth_bounds(var: str, history_actual: List[float]) -> Tuple[float, float, str]:
    """Growth corridor derived from 1990-2024 actual data only.
    """
    hist = np.asarray(history_actual, dtype=float)

    if var in POSITIVE_VARS:
        g = np.diff(np.log1p(np.maximum(hist, 0.0)))
        if len(g) == 0:
            q10, q90, iqr = -0.05, 0.05, 0.0
        else:
            q10 = float(np.quantile(g, 0.10))
            q90 = float(np.quantile(g, 0.90))
            iqr = float(np.quantile(g, 0.75) - np.quantile(g, 0.25))

        low = q10 - 0.10 * iqr
        high = q90 + 0.10 * iqr

        if var == "Area operated at 30 June (ha)":
            low, high = max(low, -0.08), min(high, 0.08)
        elif var == "Total area cropped (ha)":
            low, high = max(low, -0.10), min(high, 0.10)
        elif var == "Total area irrigated (ha)":
            low, high = max(low, -0.15), min(high, 0.15)
        elif var in {"Beef herd at 30 June (no.)", "Sheep flock at 30 June (no.)"}:
            low, high = max(low, -0.10), min(high, 0.10)
        else:
            low, high = max(low, -0.15), min(high, 0.15)

        if high < 0.01:
            high = 0.01
        if low > -0.01:
            low = -0.01

        return float(low), float(high), "log"

    d = np.diff(hist)
    if len(d) == 0:
        q10, q90, iqr = -1.0, 1.0, 0.0
    else:
        q10 = float(np.quantile(d, 0.10))
        q90 = float(np.quantile(d, 0.90))
        iqr = float(np.quantile(d, 0.75) - np.quantile(d, 0.25))

    low = q10 - 0.10 * iqr
    high = q90 + 0.10 * iqr
    scale = max(float(np.std(hist, ddof=1)) if len(hist) >= 2 else 1.0, 1.0)
    low = max(low, -0.25 * scale)
    high = min(high, 0.25 * scale)
    return float(low), float(high), "diff"


# Apply growth corridors and caps; positive variables use log growth, signed variables use differences.
def apply_constraints(var: str, candidate: np.ndarray, start_2027: float, history_actual: List[float]) -> np.ndarray:
    """Apply historical growth corridor and a modest upper cap.
    """
    arr = np.asarray(candidate, dtype=float).copy()
    upper_cap = historical_upper_cap(var, history_actual)
    g_low, g_high, mode = historical_growth_bounds(var, history_actual)
    prev, out = float(start_2027), np.zeros_like(arr, dtype=float)
    for i, x in enumerate(arr):
        x = float(x)
        if var in POSITIVE_VARS:
            x = max(0.0, x)
            g = min(g_high, max(g_low, math.log1p(x) - math.log1p(max(prev, 0.0))))
            x = min(max(0.0, math.expm1(math.log1p(max(prev, 0.0)) + g)), upper_cap)
        else:
            d = min(g_high, max(g_low, x - prev))
            x = min(max(prev + d, -upper_cap), upper_cap)
        out[i] = prev = x
    return out

# Choose a representative constrained, non-mechanical forecast path from ARIMA baseline and simulations.
def choose_representative_path(
    var: str,
    history_actual: List[float],
    official_series: Mapping[int, float],
    fit_info: Dict[str, object],
    start_year: int,
    end_year: int,
    ftype: str,
) -> Tuple[np.ndarray, Dict[str, object]]:
    """Build a baseline and choose one representative ARIMA-simulation path.
    """
    res = fit_info["result"]
    use_log = bool(fit_info["use_log"])
    horizon_total = end_year - 2025 + 1  # 2025..end
    point_work = np.asarray(res.forecast(steps=horizon_total), dtype=float)
    point_orig = inverse_transform(point_work, use_log)
    if use_log:
        point_orig = np.maximum(point_orig, 0.0)

    years_total = list(range(2025, end_year + 1))
    point_work_map = {y: point_work[i] for i, y in enumerate(years_total)}

    off_2024 = nz(official_series[2024])
    off_2027 = nz(official_series[2027])

    # Step 1: build the base path with only a light official reference.
    base_work: Dict[int, float] = {}
    if use_log:
        z_2024 = math.log1p(max(off_2024, 0.0))
        z_2027 = math.log1p(max(off_2027, 0.0))
        g_off = (z_2027 - z_2024) / 3.0
        prev = z_2027
        for y in range(start_year, end_year + 1):
            g_point = point_work_map[y] - point_work_map[y - 1]
            a = official_weight(y)
            g = (1.0 - a) * g_point + a * g_off
            prev = prev + g
            base_work[y] = prev
        base_orig = np.maximum(np.expm1(np.array([base_work[y] for y in range(start_year, end_year + 1)])), 0.0)
    else:
        d_off = (off_2027 - off_2024) / 3.0
        prev = off_2027
        for y in range(start_year, end_year + 1):
            d_point = point_work_map[y] - point_work_map[y - 1]
            a = official_weight(y)
            d = (1.0 - a) * d_point + a * d_off
            prev = prev + d
            base_work[y] = prev
        base_orig = np.array([base_work[y] for y in range(start_year, end_year + 1)], dtype=float)

    # Step 2: simulate future ARIMA paths and add only a damped deviation
    rng_seed = abs(hash((ftype, var))) % (2**32)
    rng = np.random.default_rng(rng_seed)

    try:
        sim = res.simulate(nsimulations=horizon_total, repetitions=300, anchor="end", random_state=rng)
        sim = squeeze_simulation_array(sim)
    except Exception:
        sim = np.tile(point_work.reshape(-1, 1), 50)

    if sim.shape[0] != horizon_total and sim.shape[1] == horizon_total:
        sim = sim.T

    damp = np.linspace(0.45, 0.25, end_year - start_year + 1)
    start_idx = start_year - 2025

    scale = max(float(np.std(history_actual, ddof=1)) if len(history_actual) >= 2 else 1.0, 1.0)
    upper_cap = historical_upper_cap(var, history_actual)
    best_path: Optional[np.ndarray] = None
    best_score = 1e99
    best_meta: Dict[str, object] = {}

    for j in range(sim.shape[1]):
        sim_col = sim[:, j]
        work_candidate: List[float] = []

        for k, y in enumerate(range(start_year, end_year + 1)):
            dev = float(sim_col[start_idx + k] - point_work[start_idx + k])
            work_candidate.append(base_work[y] + damp[k] * dev)

        work_candidate_arr = np.asarray(work_candidate, dtype=float)
        orig_candidate = inverse_transform(work_candidate_arr, use_log)
        if use_log:
            orig_candidate = np.maximum(orig_candidate, 0.0)

        filtered = apply_constraints(
            var=var,
            candidate=orig_candidate,
            start_2027=off_2027,
            history_actual=history_actual,
        )

        diffs = np.diff(filtered)
        n_pos = int(np.sum(diffs > 1e-9))
        n_neg = int(np.sum(diffs < -1e-9))
        sign_changes = int(np.sum((diffs[1:] * diffs[:-1]) < 0)) if len(diffs) >= 2 else 0

        # Scoring rule
        # 1) strongly penalize fully monotonic paths
        # 2) require at least some
        # 3) stay close to base path
        # 4) avoid sitting on the cap too often
        monotonic_pen = 25.0 if (n_pos == 0 or n_neg == 0) else 0.0
        fold_pen = 0.0
        if sign_changes == 0:
            fold_pen += 10.0
        elif sign_changes > 8:
            fold_pen += 0.5 * (sign_changes - 8)

        smooth_pen = float(np.mean(((filtered - base_orig) / (scale + 1e-9)) ** 2))
        end_pen = float(((filtered[-1] - base_orig[-1]) / (scale + 1e-9)) ** 2)
        cap_pen = float(np.sum(np.isclose(filtered, upper_cap, rtol=1e-5, atol=1e-8)) * 1.0)

        # If the base path rises overall, prefer a representative path that also
        # ends above the 2027 level, but not necessarily every year.
        trend_pen = 0.0
        if base_orig[-1] > off_2027 * 1.01 and filtered[-1] < off_2027 * 0.99:
            trend_pen += 8.0

        score = monotonic_pen + fold_pen + smooth_pen + 0.25 * end_pen + cap_pen + trend_pen

        if score < best_score:
            best_score = score
            best_path = filtered
            best_meta = {
                "cap": upper_cap,
                "sign_changes": sign_changes,
                "n_pos": n_pos,
                "n_neg": n_neg,
                "score": score,
            }

    if best_path is None:
        best_path = apply_constraints(
            var=var,
            candidate=base_orig,
            start_2027=off_2027,
            history_actual=history_actual,
        )
        best_meta = {
            "cap": upper_cap,
            "sign_changes": 0,
            "n_pos": 0,
            "n_neg": 0,
            "score": 999.0,
        }

    return best_path, best_meta


# Compute helper financial series such as other receipts/costs and profit gaps.
def compute_helper_series(visible: Mapping[str, Dict[int, float]]) -> Dict[str, Dict[int, float]]:
    years = sorted(visible["Total cash receipts ($)"].keys())
    helpers: Dict[str, Dict[int, float]] = {"Other cash receipts ($)": {}, "Other cash costs ($)": {}, "Profit gap ($)": {}, "Full-equity gap ($)": {}}
    for y in years:
        helpers["Other cash receipts ($)"][y] = nz(visible["Total cash receipts ($)"][y]) - nz(visible["Total crop gross receipts ($)"][y]) - nz(visible["Beef cattle receipts ($)"][y]) - nz(visible["Sheep receipts ($)"][y]) - nz(visible["Wool receipts ($)"][y])
        helpers["Other cash costs ($)"][y] = nz(visible["Total cash costs ($)"][y]) - nz(visible["Electricity ($)"][y]) - nz(visible["Water charges ($)"][y])
        helpers["Profit gap ($)"][y] = nz(visible["Farm cash income ($)"][y]) - nz(visible["Farm business profit ($)"][y])
        helpers["Full-equity gap ($)"][y] = nz(visible["Profit at full equity ($)"][y]) - nz(visible["Farm business profit ($)"][y])
    return helpers

# Derive forecast-year structural and financial rows using recent ratios and accounting closure.
def derive_structural_and_financial_series(data: Dict[str, Dict[int, float]], forecast_years: List[int]) -> None:
    recent_years = range(2021, 2025)
    crop_shares = {v: max(0.0, recent_mean_ratio(data[v], data["Total area cropped (ha)"], recent_years, default=0.0)) for v in CROP_AREA_VARS}
    share_sum = sum(crop_shares.values())
    if share_sum > 1.0 and share_sum > 0.0:
        crop_shares = {k: v / share_sum for k, v in crop_shares.items()}
    crop_yields = {o: max(0.0, recent_mean_ratio(data[o], data[a], recent_years, default=0.0)) for o, a in CROP_OUTPUT_AREA_MAP.items()}
    output_receipt_rate: Dict[str, float] = {}
    for receipt_var, out_var in CROP_RECEIPT_OUTPUT_MAP.items():
        rate = recent_mean_ratio(data[receipt_var], data[out_var], recent_years, default=float("nan"))
        if math.isnan(rate):
            rate = recent_mean_ratio(data[receipt_var], data[CROP_OUTPUT_AREA_MAP[out_var]], recent_years, default=0.0)
        output_receipt_rate[receipt_var] = max(0.0, rate)
    area_receipt_rate = {r: max(0.0, recent_mean_ratio(data[r], data[a], recent_years, default=0.0)) for r, a in CROP_RECEIPT_AREA_MAP.items()}
    cotton_share = max(0.0, recent_mean_ratio(data["Cotton receipts ($)"], data["Total crop gross receipts ($)"], recent_years, default=0.0))
    subgroup_ratio = {v: min(max(0.0, recent_mean_ratio(data[v], data["Sheep flock at 30 June (no.)"], recent_years, default=0.0)), cap) for v, cap in SHEEP_SUBGROUP_CAPS.items()}
    sold_per_shorn = max(0.0, recent_mean_ratio(data["Total wool sold (kg)"], data["Sheep and lambs shorn (no.)"], recent_years, default=0.0))
    produced_per_shorn = max(0.0, recent_mean_ratio(data["Wool produced (kg)"], data["Sheep and lambs shorn (no.)"], recent_years, default=0.0))
    for y in forecast_years:
        data["Area operated at 30 June (ha)"][y] = max(0.0, nz(data["Area operated at 30 June (ha)"][y]))
        data["Total area cropped (ha)"][y] = min(max(0.0, nz(data["Total area cropped (ha)"][y])), data["Area operated at 30 June (ha)"][y])
        data["Total area irrigated (ha)"][y] = min(max(0.0, nz(data["Total area irrigated (ha)"][y])), data["Total area cropped (ha)"][y])
        total_crop = data["Total area cropped (ha)"][y]
        for var in CROP_AREA_VARS:
            data[var][y] = max(0.0, crop_shares[var] * total_crop)
        for out_var, area_var in CROP_OUTPUT_AREA_MAP.items():
            data[out_var][y] = max(0.0, crop_yields[out_var] * data[area_var][y])
        flock = max(0.0, nz(data["Sheep flock at 30 June (no.)"][y]))
        for var, cap in SHEEP_SUBGROUP_CAPS.items():
            data[var][y] = max(0.0, min(cap * flock, subgroup_ratio[var] * flock))
        shorn = data["Sheep and lambs shorn (no.)"][y]
        data["Total wool sold (kg)"][y], data["Wool produced (kg)"][y] = max(0.0, sold_per_shorn * shorn), max(0.0, produced_per_shorn * shorn)
        component_sum = 0.0
        for receipt_var, out_var in CROP_RECEIPT_OUTPUT_MAP.items():
            value = max(0.0, output_receipt_rate[receipt_var] * data[out_var][y]); data[receipt_var][y] = value; component_sum += value
        for receipt_var, area_var in CROP_RECEIPT_AREA_MAP.items():
            value = max(0.0, area_receipt_rate[receipt_var] * data[area_var][y]); data[receipt_var][y] = value; component_sum += value
        data["Cotton receipts ($)"][y] = max(0.0, cotton_share * data["Total crop gross receipts ($)"][y]); component_sum += data["Cotton receipts ($)"][y]
        total_crop_receipts = data["Total crop gross receipts ($)"][y]
        if component_sum > total_crop_receipts and component_sum > 1e-12:
            scale = total_crop_receipts / component_sum
            for receipt_var in list(CROP_RECEIPT_OUTPUT_MAP) + list(CROP_RECEIPT_AREA_MAP) + ["Cotton receipts ($)"]:
                data[receipt_var][y] *= scale
        data["Total cash receipts ($)"][y] = data["Total crop gross receipts ($)"][y] + data["Beef cattle receipts ($)"][y] + data["Sheep receipts ($)"][y] + data["Wool receipts ($)"][y] + data["Other cash receipts ($)"][y]
        data["Total cash costs ($)"][y] = data["Electricity ($)"][y] + data["Water charges ($)"][y] + data["Other cash costs ($)"][y]
        data["Farm cash income ($)"][y] = data["Total cash receipts ($)"][y] - data["Total cash costs ($)"][y]
        data["Farm business profit ($)"][y] = data["Farm cash income ($)"][y] - data["Profit gap ($)"][y]
        data["Profit at full equity ($)"][y] = data["Farm business profit ($)"][y] + data["Full-equity gap ($)"][y]


# Build forecast data while preserving 1990-2027 exactly.
def build_forecast_data(wb: openpyxl.Workbook, start_year: int, end_year: int) -> Tuple[Dict[str, Dict[str, Dict[int, float]]], Dict[Tuple[str, str], Dict[str, object]], Dict[str, object]]:
    forecast_years = list(range(start_year, end_year + 1))
    results: Dict[str, Dict[str, Dict[int, float]]] = {}
    model_meta: Dict[Tuple[str, str], Dict[str, object]] = {}
    for ftype in FARM_TYPES:
        ws = wb[WDCH_SHEETS[ftype]]
        visible = {var: read_visible_series(ws, var) for var in get_row_map(ws).keys()}
        data = {var: dict(series) for var, series in visible.items()}
        data.update({var: dict(series) for var, series in compute_helper_series(visible).items()})
        # Forecast only 2028-2044; 1990-2027 are untouched.
        for var in DIRECT_VARS + HELPER_VARS:
            history_actual = [data[var][y] for y in range(1990, 2025)]  # actual history only
            official_series = {y: data[var][y] for y in range(2024, 2028)}  # light reference only
            fit_info = fit_select_arima(history_actual, var)
            rep_path, rep_meta = choose_representative_path(var=var, history_actual=history_actual, official_series=official_series, fit_info=fit_info, start_year=start_year, end_year=end_year, ftype=ftype)
            for idx, y in enumerate(forecast_years):
                data[var][y] = float(rep_path[idx])
            model_meta[(ftype, var)] = {k: fit_info[k] for k in ["order", "trend", "use_log", "holdout_mase"]} | {k: rep_meta[k] for k in ["cap", "sign_changes", "n_pos", "n_neg", "score"]}
        derive_structural_and_financial_series(data, forecast_years)
        results[ftype] = data
    checks = run_quality_checks(results, wb, forecast_years)
    return results, model_meta, checks

# Insert 2028-2044 forecast-year columns and copy workbook formatting.
def insert_future_columns(ws: openpyxl.worksheet.worksheet.Worksheet, future_years_desc: List[int]) -> None:
    if not future_years_desc or max(get_years(ws)) >= max(future_years_desc):
        return
    n_new = len(future_years_desc)
    ws.insert_cols(2, amount=n_new)
    template_col = 2 + n_new  # original first year column shifted right
    template_letter = openpyxl.utils.get_column_letter(template_col)
    style_attrs = ["number_format", "font", "fill", "border", "alignment", "protection"]
    for offset in range(n_new):
        col_idx, col_letter = 2 + offset, openpyxl.utils.get_column_letter(2 + offset)
        ws.column_dimensions[col_letter].width = ws.column_dimensions[template_letter].width
        for r in range(1, ws.max_row + 1):
            src, dst = ws.cell(r, template_col), ws.cell(r, col_idx)
            if src.has_style:
                dst._style = copy(src._style)
            for attr in style_attrs:
                v = getattr(src, attr)
                if v:
                    setattr(dst, attr, copy(v))
    for idx, year in enumerate(future_years_desc, start=2):
        ws.cell(7, idx).value = year



def write_results_to_workbook(wb: openpyxl.Workbook, results: Mapping[str, Mapping[str, Mapping[int, float]]], start_year: int, end_year: int) -> None:
    future_years_desc = list(range(end_year, start_year - 1, -1))
    for ftype in FARM_TYPES:
        ws = wb[WDCH_SHEETS[ftype]]
        insert_future_columns(ws, future_years_desc)
        row_map, col_map = get_row_map(ws), get_col_map(ws)
        for var, r in row_map.items():
            series = results[ftype].get(var)
            if series:
                for y in range(start_year, end_year + 1):
                    ws.cell(r, col_map[y]).value = float(series[y])


# Run checks for data preservation, area constraints, and financial closure.
def run_quality_checks(results: Mapping[str, Mapping[str, Mapping[int, float]]], source_wb: openpyxl.Workbook, forecast_years: Iterable[int]) -> Dict[str, object]:
    hard_violations: List[str] = []
    soft_flags: List[str] = []
    unchanged_violations: List[str] = []
    for ftype in FARM_TYPES:
        source_ws = source_wb[WDCH_SHEETS[ftype]]
        source_rows, source_cols, data = get_row_map(source_ws), get_col_map(source_ws), results[ftype]
        # Check 1990-2027 were not altered in memory.
        for var in source_rows.keys():
            for y in range(1990, 2028):
                if abs(nz(source_ws.cell(source_rows[var], source_cols[y]).value) - nz(data[var][y])) > 1e-9:
                    unchanged_violations.append(f"{ftype} {var} {y}: original data changed")
        for y in forecast_years:
            total_crop, operated, irrigated = nz(data["Total area cropped (ha)"][y]), nz(data["Area operated at 30 June (ha)"][y]), nz(data["Total area irrigated (ha)"][y])
            crop_component_sum = sum(nz(data[var][y]) for var in CROP_AREA_VARS)
            for cond, msg in [(total_crop - operated > 1e-6, "total area cropped > area operated"), (irrigated - total_crop > 1e-6, "total area irrigated > total area cropped"), (crop_component_sum - total_crop > 1e-6, "crop-area components > total area cropped")]:
                if cond:
                    hard_violations.append(f"{ftype} {y}: {msg}")
            receipts = nz(data["Total cash receipts ($)"][y])
            receipt_rhs = nz(data["Total crop gross receipts ($)"][y]) + nz(data["Beef cattle receipts ($)"][y]) + nz(data["Sheep receipts ($)"][y]) + nz(data["Wool receipts ($)"][y]) + nz(data["Other cash receipts ($)"][y])
            if abs(receipts - receipt_rhs) > 1e-6:
                hard_violations.append(f"{ftype} {y}: cash receipts closure failed")
            costs = nz(data["Total cash costs ($)"][y])
            cost_rhs = nz(data["Electricity ($)"][y]) + nz(data["Water charges ($)"][y]) + nz(data["Other cash costs ($)"][y])
            if abs(costs - cost_rhs) > 1e-6:
                hard_violations.append(f"{ftype} {y}: cash costs closure failed")
        # to avoid completely monotonic visible paths for key drivers.
        for var in ["Area operated at 30 June (ha)", "Total area cropped (ha)", "Beef herd at 30 June (no.)", "Total crop gross receipts ($)", "Electricity ($)", "Water charges ($)"]:
            diffs = np.diff(np.array([nz(data[var][y]) for y in forecast_years], dtype=float))
            if np.all(diffs >= -1e-9) or np.all(diffs <= 1e-9):
                soft_flags.append(f"{ftype} {var}: forecast path is still monotonic")
    return {"hard_count": len(hard_violations), "soft_count": len(soft_flags), "unchanged_count": len(unchanged_violations), "hard_violations": hard_violations, "soft_flags": soft_flags, "unchanged_violations": unchanged_violations}


def main(argv: Optional[List[str]] = None) -> None:
    args = parse_args(argv)
    input_path, output_path = Path(args.input), Path(args.output)
    wb = openpyxl.load_workbook(input_path)
    results, model_meta, checks = build_forecast_data(wb, args.start_year, args.end_year)
    write_results_to_workbook(wb, results, args.start_year, args.end_year)
    wb.save(output_path)
    for line in [
        f"Saved output workbook: {output_path}",
        f"Updated only forecast years: {args.start_year}-{args.end_year}",
        f"Unchanged-data violations: {checks['unchanged_count']}",
        f"Hard-check violations: {checks['hard_count']}",
        f"Soft-check flags: {checks['soft_count']}",
    ]:
        print(line)
    for ftype in FARM_TYPES:
        print(f"\\n[{ftype}]")
        for var in ["Area operated at 30 June (ha)", "Total area cropped (ha)", "Beef herd at 30 June (no.)", "Total crop gross receipts ($)", "Electricity ($)", "Other cash receipts ($)", "Other cash costs ($)", "Profit gap ($)"]:
            meta = model_meta[(ftype, var)]
            print(f"  {var}: ARIMA{meta['order']} trend={meta['trend']} " f"log={'yes' if meta['use_log'] else 'no'} " f"MASE={meta['holdout_mase']:.3f} " f"sign_changes={meta['sign_changes']} cap={meta['cap']:.2f}")
    for key, title in [("unchanged_violations", "Data-preservation violations:"), ("hard_violations", "Hard violations:"), ("soft_flags", "Soft flags:")]:
        if checks[key]:
            print(f"\\n{title}")
            for msg in checks[key]:
                print(" -", msg)


if __name__ == "__main__":
    main()
