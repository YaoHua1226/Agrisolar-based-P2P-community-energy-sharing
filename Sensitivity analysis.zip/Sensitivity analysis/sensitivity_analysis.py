"""
This script uses the Stage 1 Best PV area optimal PV result to run a one-at-a-time
sensitivity analysis and writes the same summary CSV and NPV tornado plot outputs.

Main formulas
Scaled PV generation is PV'_t = min(PV_t * m_pv, AC_kW).
SelfUse_t = min(PV'_t, Load_t); Export_t = max(PV'_t - Load_t, 0).
Annual net cashflow is CF_y = SelfUseValue_y + Export_y * FiT - OPEX_y - AgCost_y.
Discounted cashflow is DCF_y = CF_y / (1+r)^(y-install_year), and NPV = -CAPEX + Σ DCF_y.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

INSTALL_YEAR = 2024
DISCOUNT_RATE = 0.06
BASELINE_AG_GM = 3315.0
BASELINE_FIT = 0.0866

BASE_CFG = {"fit": BASELINE_FIT, "capex_mult": 1.00, "ag_gm": BASELINE_AG_GM, "pv_mult": 1.00}
SCENARIOS = [
    ("baseline", "baseline", None),
    ("fit", "low", 0.06583), ("fit", "high", 0.12377),
    ("capex_mult", "low", 0.85), ("capex_mult", "high", 1.15),
    ("ag_gm", "low", 0.0), ("ag_gm", "high", 6000.0),
    ("pv_mult", "low", 0.90), ("pv_mult", "high", 1.05),
]
LABELS = {
    "fit": "FiT",
    "capex_mult": "CAPEX",
    "ag_gm": "Agricultural\nopportunity cost",
    "pv_mult": "PV generation",
}
CHANGE_LABELS = {
    "fit": ("Low: 6.58 c/kWh", "High: 12.38 c/kWh"),
    "capex_mult": ("Low: -15%", "High: +15%"),
    "ag_gm": ("Low: $0/ha", "High: $6,000/ha"),
    "pv_mult": ("Low: -10%", "High: +5%"),
}


def paths() -> tuple[Path, Path]:
    sens_dir = Path(__file__).resolve().parent
    best_pv_dir = sens_dir.parent / "Best PV area"
    out_dir = sens_dir / "outputs"
    out_dir.mkdir(parents=True, exist_ok=True)
    return best_pv_dir, out_dir


def load_inputs(best_pv_dir: Path) -> dict[str, pd.DataFrame | float]:
    out = best_pv_dir / "outputs"
    summary = pd.read_csv(out / "optimal_pv_area_summary.csv")
    cashflow = pd.read_csv(out / "optimal_pv_area_best_cashflows.csv").sort_values("Year")
    hourly = pd.read_csv(out / "optimal_pv_area_best_hourly_timeseries.csv", parse_dates=["timestamp"])
    calibration = pd.read_csv(out / "annual_bill_calibration.csv")
    price = pd.read_csv(best_pv_dir / "qld1_forecast_hourly_2025_2044.csv", parse_dates=["SETTLEMENTDATE"])
    price = price.rename(columns={"SETTLEMENTDATE": "timestamp", "RRP_pred": "rrp_aud_per_mwh"})
    price["price_aud_per_kwh_nonneg"] = (price["rrp_aud_per_mwh"] / 1000.0).clip(lower=0.0)
    return {
        "cashflow": cashflow,
        "hourly": hourly,
        "calibration": calibration,
        "price": price[["timestamp", "price_aud_per_kwh_nonneg"]],
        "capex": float(summary.loc[0, "optimal_capex_aud"]),
        "ac_kw": float(summary.loc[0, "optimal_ac_kw"]),
    }

# Build a one-at-a-time scenario configuration and verify that only the selected parameter changes.
def make_cfg(param: str, value) -> dict[str, float]:
    cfg = BASE_CFG.copy()
    if param != "baseline":
        cfg[param] = float(value)
    changed = [k for k in BASE_CFG if not np.isclose(cfg[k], BASE_CFG[k])]
    expected = [] if param == "baseline" else [param]
    if changed != expected:
        raise ValueError(f"Only one parameter may change. Expected {expected}, got {changed}.")
    return cfg

# Calculate discounted payback by linearly interpolating where cumulative discounted cashflow crosses zero.
def payback_year(capex: float, years: np.ndarray, discounted_cf: np.ndarray) -> tuple[float, float]:
    cumulative = -capex
    for i, cf in enumerate(discounted_cf):
        prev = cumulative
        cumulative += float(cf)
        if prev < 0 <= cumulative and cf > 1e-12:
            year = years[i] if i == 0 else years[i - 1] + (-prev / cf)
            return float(year - INSTALL_YEAR), float(year)
    return float("nan"), float("nan")

# Recompute hourly PV self-use, export, and self-use value when the PV multiplier changes; otherwise reuse the base cashflow.
def pv_case(data: dict, cfg: dict[str, float]) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    cash = data["cashflow"]
    if np.isclose(cfg["pv_mult"], 1.0):
        return tuple(cash[c].to_numpy(float) for c in ["PV_Generation_kWh", "Self_Used_kWh", "Exported_kWh", "SelfUse_Value_AUD"])

    h = data["hourly"].merge(data["price"], on="timestamp", how="left")
    h = h.merge(data["calibration"][["Year", "Lambda_Year"]], left_on="year", right_on="Year", how="left")
    pv = np.minimum(h["pv_generation_kwh"].to_numpy(float) * cfg["pv_mult"], data["ac_kw"])
    load = h["load_kwh"].to_numpy(float)
    self_used = np.minimum(pv, load)
    exported = np.maximum(pv - load, 0.0)
    value = self_used * h["price_aud_per_kwh_nonneg"].to_numpy(float) * h["Lambda_Year"].to_numpy(float)
    g = pd.DataFrame({
        "Year": h["year"].to_numpy(int),
        "PV_Generation_kWh": pv,
        "Self_Used_kWh": self_used,
        "Exported_kWh": exported,
        "SelfUse_Value_AUD": value,
    }).groupby("Year", as_index=False).sum().sort_values("Year")
    return tuple(g[c].to_numpy(float) for c in ["PV_Generation_kWh", "Self_Used_kWh", "Exported_kWh", "SelfUse_Value_AUD"])

# Recalculate annual cashflows, discounted cashflows, NPV, and key mean indicators for one scenario.
def evaluate(data: dict, cfg: dict[str, float]) -> dict[str, float]:
    cash = data["cashflow"]
    years = cash["Year"].to_numpy(int)
    capex = data["capex"] * cfg["capex_mult"]
    pv_gen, self_used, exported, self_value = pv_case(data, cfg)
    export_value = exported * cfg["fit"]
    ag_cost = cash["Ag_Opportunity_Cost_AUD"].to_numpy(float) * (cfg["ag_gm"] / BASELINE_AG_GM)
    net_cf = self_value + export_value - cash["Annual_OPEX_AUD"].to_numpy(float) - ag_cost
    discounted_cf = net_cf / ((1 + DISCOUNT_RATE) ** (years - INSTALL_YEAR))
    payback, calendar = payback_year(capex, years, discounted_cf)
    return {
        "NPV_AUD": float(-capex + discounted_cf.sum()),
        "Discounted_Payback_Years": payback,
        "Discounted_Payback_Calendar_Year": calendar,
        "CAPEX_AUD": capex,
        "Mean_Annual_PV_Generation_kWh": float(np.mean(pv_gen)),
        "Mean_Annual_Self_Used_kWh": float(np.mean(self_used)),
        "Mean_Annual_Exported_kWh": float(np.mean(exported)),
        "Mean_Annual_SelfUse_Value_AUD": float(np.mean(self_value)),
        "Mean_Annual_Export_Value_AUD": float(np.mean(export_value)),
        "Mean_Annual_Agricultural_Opportunity_Cost_AUD": float(np.mean(ag_cost)),
        "Mean_Annual_Net_Cashflow_AUD": float(np.mean(net_cf)),
    }


def build_summary(data: dict) -> pd.DataFrame:
    rows = []
    for param, case, value in SCENARIOS:
        cfg = make_cfg(param, value)
        row = {
            "Parameter": param,
            "Parameter_Label": LABELS.get(param, "Baseline"),
            "Case": case,
            "Value": value if value is not None else "baseline",
            "fit_aud_per_kwh": cfg["fit"],
            "capex_multiplier": cfg["capex_mult"],
            "ag_gross_margin_aud_per_ha": cfg["ag_gm"],
            "pv_generation_multiplier": cfg["pv_mult"],
        }
        row.update(evaluate(data, cfg))
        rows.append(row)
    df = pd.DataFrame(rows)
    baseline_npv = float(df.loc[df["Parameter"] == "baseline", "NPV_AUD"].iloc[0])
    df["NPV_Change_AUD"] = df["NPV_AUD"] - baseline_npv
    df["NPV_Change_pct"] = df["NPV_Change_AUD"] / baseline_npv * 100.0
    return df


def plot_tornado(summary: pd.DataFrame, outpath: Path) -> None:
    base = float(summary.loc[summary["Parameter"] == "baseline", "NPV_AUD"].iloc[0])
    rows = []
    for param, g in summary[summary["Parameter"] != "baseline"].groupby("Parameter", sort=False):
        low = g.loc[g["NPV_AUD"].idxmin()]
        high = g.loc[g["NPV_AUD"].idxmax()]
        rows.append({
            "param": param,
            "label": LABELS[param],
            "low_npv": float(low["NPV_AUD"]),
            "high_npv": float(high["NPV_AUD"]),
            "low_pct": float(low["NPV_Change_pct"]),
            "high_pct": float(high["NPV_Change_pct"]),
            "low_change_label": CHANGE_LABELS[param][0],
            "high_change_label": CHANGE_LABELS[param][1],
            "span": float(high["NPV_AUD"] - low["NPV_AUD"]),
        })
    plot_df = pd.DataFrame(rows).sort_values("span", ascending=False).reset_index(drop=True)

    fig, ax = plt.subplots(figsize=(15.0, 6.9))
    y = np.arange(len(plot_df))
    max_high = float(plot_df["high_npv"].max())
    min_low = float(min(0.0, plot_df["low_npv"].min()))
    left_margin = max(base * 0.025, 900)
    right_margin = max(base * 0.22, 14500)
    value_offset = max(base * 0.012, 500)
    change_offset = max(base * 0.055, 2300)

    for i, r in plot_df.iterrows():
        ax.barh(i, base - r.low_npv, left=r.low_npv, height=0.8, color="#e77c7c", edgecolor="white")
        ax.barh(i, r.high_npv - base, left=base, height=0.8, color="#87c6e0", edgecolor="white")
        low_val_x = max(min_low + 300, r.low_npv - value_offset)
        high_val_x = min(max_high + right_margin - 250, r.high_npv + value_offset)
        low_chg_x = max(min_low + 300, r.low_npv - change_offset)
        high_chg_x = min(max_high + right_margin - 250, r.high_npv + change_offset)
        ax.text(low_val_x, i - 0.10, f"${r.low_npv:,.0f} ({r.low_pct:+.1f}%)", ha="right", va="center", color="#b22222", fontsize=10)
        ax.text(low_chg_x, i + 0.18, r.low_change_label, ha="right", va="center", color="#7a1f1f", fontsize=9)
        ax.text(high_val_x, i - 0.10, f"${r.high_npv:,.0f} ({r.high_pct:+.1f}%)", ha="left", va="center", color="#1f3ba6", fontsize=10)
        ax.text(high_chg_x, i + 0.18, r.high_change_label, ha="left", va="center", color="#174a63", fontsize=9)

    ax.axvline(base, color="black", linestyle="--", linewidth=2, label=f"Base case NPV (${base:,.0f})")
    ax.axvline(0, color="red", linestyle="--", linewidth=2, label="Break-even ($0)")
    ax.set_xlim(min_low - left_margin, max_high + right_margin)
    ax.set_yticks(y)
    ax.set_yticklabels(plot_df["label"])
    ax.invert_yaxis()
    ax.set_xlabel("NPV (AUD)")
    ax.set_title("NPV Sensitivity to Key Variables")
    ax.grid(axis="x", linestyle="--", alpha=0.5)
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(outpath, dpi=200, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    best_pv_dir, out_dir = paths()
    summary = build_summary(load_inputs(best_pv_dir))
    summary.to_csv(out_dir / "sensitivity_summary.csv", index=False)
    plot_tornado(summary, out_dir / "sensitivity_tornado_npv_pct.png")


if __name__ == "__main__":
    main()
